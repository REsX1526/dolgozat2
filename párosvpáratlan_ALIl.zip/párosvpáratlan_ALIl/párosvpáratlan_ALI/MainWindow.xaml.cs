﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace párosvpáratlan_ALI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            int i = int.Parse(box.Text);

            if(i > 1000)
            {
                MessageBox.Show("Ez a szám nagyobb mint 1000 kérlek adj meg egy másik számot");
            }

            if(i % 2 == 0)
            {
                pvp.Content = "Ez a szám páros";
            }

            if (i % 2 == 1)
            {
                pvp.Content = "Ez a szám páratlan";
            }
        }
    }
}
